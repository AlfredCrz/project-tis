<!-- Nombre Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nombre', 'Nombre:'); ?>

    <?php echo Form::text('nombre', null, ['class' => 'form-control']); ?>

</div>

<!-- Codigo Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('codigo', 'Codigo:'); ?>

    <?php echo Form::number('codigo', null, ['class' => 'form-control']); ?>

</div>

<!-- Gestion Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('gestion', 'Gestion:'); ?>

    <?php echo Form::text('gestion', null, ['class' => 'form-control']); ?>

</div>

<!-- Grupo Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('grupo_id', 'Grupo Id:'); ?>

    <?php echo Form::select('grupo_id', $grupos, null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('materias.index'); ?>" class="btn btn-default">Cancelar</a>
</div>
