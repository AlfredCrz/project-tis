<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $materias->id !!}</p>
</div>

<!-- Nombre Field -->
<div class="form-group">
    {!! Form::label('nombre', 'Nombre:') !!}
    <p>{!! $materias->nombre !!}</p>
</div>

<!-- Codigo Field -->
<div class="form-group">
    {!! Form::label('codigo', 'Codigo:') !!}
    <p>{!! $materias->codigo !!}</p>
</div>

<!-- Gestion Field -->
<div class="form-group">
    {!! Form::label('gestion', 'Gestion:') !!}
    <p>{!! $materias->gestion !!}</p>
</div>

<!-- Grupo Id Field -->
<div class="form-group">
    {!! Form::label('grupo_id', 'Grupo Id:') !!}
    <p>{!! $materias->grupo_id !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $materias->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $materias->updated_at !!}</p>
</div>

