<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $grupos->id !!}</p>
</div>

<!-- Dia Field -->
<div class="form-group">
    {!! Form::label('dia', 'Dia:') !!}
    <p>{!! $grupos->dia !!}</p>
</div>

<!-- Horario Id Field -->
<div class="form-group">
    {!! Form::label('horario_id', 'Horario Id:') !!}
    <p>{!! $grupos->horario_id !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $grupos->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $grupos->updated_at !!}</p>
</div>

