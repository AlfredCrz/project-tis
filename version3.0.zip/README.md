# adminlte-generator (Coming Soon...)
### Boilerplate of Laravel with InfyOm Laravel Generator for AdminLTE Templates

This is a fresh new laravel package with all [InfyOm Laravel Generator](https://github.com/InfyOmLabs/laravel-generator) installed.

You can use this, if you want to get started with your fresh new laravel project and generate CRUD by skipping all installation steps.