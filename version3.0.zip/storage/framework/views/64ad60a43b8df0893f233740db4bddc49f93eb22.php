<!-- Hora Inicio Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('hora_inicio', 'Hora Inicio:'); ?>

    <?php echo Form::time('hora_inicio', null, ['class' => 'form-control']); ?>

</div>

<!-- Hora Final Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('hora_final', 'Hora Final:'); ?>

    <?php echo Form::time('hora_final', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('horas.index'); ?>" class="btn btn-default">Cancelar</a>
</div>
